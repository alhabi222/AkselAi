'use client';

import { useEffect, useState } from 'react';
import { Loader2, PlusCircle, RotateCcw } from 'lucide-react';
import { usePartners } from '@/hooks/use-partners';
import { PartnerCard } from '@/components/partner-card';
import { Button } from '@/components/ui/button';
import { CreatePartnerDialog } from '@/components/create-partner-dialog';
import { ClientOnly } from '@/components/client-only';
import { SiteHeader } from '@/components/site-header';
import { AuthProvider } from '@/hooks/use-auth';
import { PartnersProvider } from '@/hooks/use-partners';
import { Toaster } from '@/components/ui/toaster';

function DemoPageContent() {
  const { partners, loading, resetPartners, addPartner } = usePartners();
  const [isCreateDialogOpen, setCreateDialogOpen] = useState(false);

  return (
    <>
      <div className="container mx-auto p-4 sm:p-6 lg:p-8">
        <div className="mb-8 text-center">
            <h1 className="text-3xl font-bold font-headline tracking-tight sm:text-4xl">
              Selamat Datang di Demo AkselAI
            </h1>
            <p className="mt-2 max-w-2xl text-lg text-muted-foreground mx-auto">
              Ini adalah lingkungan demo interaktif. Coba buat Partner AI Anda sendiri atau jelajahi yang sudah ada. Semua data partner di bawah ini dikelola langsung dari Notion.
            </p>
        </div>
        
        <div className="flex justify-center items-center gap-2 mb-8">
            <Button variant="outline" size="sm" onClick={resetPartners}>
              <RotateCcw className="mr-2 h-4 w-4" />
              Sinkronkan dari Notion
            </Button>
            <Button size="sm" onClick={() => setCreateDialogOpen(true)}>
              <PlusCircle className="mr-2 h-4 w-4" />
              Buat Partner Baru
            </Button>
        </div>


        <ClientOnly>
          {loading ? (
             <div className="flex h-64 w-full items-center justify-center">
                <Loader2 className="h-8 w-8 animate-spin text-accent" />
             </div>
          ) : (
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {partners.map(partner => (
                <PartnerCard
                    key={partner.slug}
                    partner={partner}
                />
                ))}
            </div>
          )}
           { !loading && partners.length === 0 && (
              <div className="text-center py-16 px-4 border-2 border-dashed rounded-lg">
                <h3 className="text-xl font-bold font-headline">Database Notion Kosong</h3>
                <p className="text-muted-foreground mt-2">
                  Tidak ada partner yang berstatus "Published" di database Notion Anda. <br/> Tambahkan beberapa partner di Notion dan klik "Sinkronkan" untuk melihatnya di sini.
                </p>
              </div>
            )}
        </ClientOnly>
      </div>
      <CreatePartnerDialog
        isOpen={isCreateDialogOpen}
        onOpenChange={setCreateDialogOpen}
        onPartnerCreated={addPartner}
      />
    </>
  );
}


export default function DemoPage() {
    return (
        <AuthProvider>
            <PartnersProvider>
                <div className="flex flex-col h-screen">
                    <SiteHeader />
                    <main className="flex-1 overflow-y-auto">
                        <DemoPageContent />
                    </main>
                    <Toaster />
                </div>
            </PartnersProvider>
        </AuthProvider>
    )
}                                                                                                                                                     
'use client';

import { useState, useEffect, useCallback, createContext, useContext, ReactNode } from 'react';
import { Partner } from '@/lib/partners';
import { useToast } from './use-toast';
import { getPartnersFromNotion } from '@/services/notion';

const PARTNERS_STORAGE_KEY = 'skillai-partners';

interface PartnersContextType {
  partners: Partner[];
  loading: boolean;
  addPartner: (newPartner: Partner) => void;
  deletePartner: (slug: string) => void;
  resetPartners: () => void;
  updatePartner: (slug: string, updatedPartner: Partner) => void;
}

const PartnersContext = createContext<PartnersContextType | undefined>(undefined);

export function PartnersProvider({ children }: { children: ReactNode }) {
  const [partners, setPartners] = useState<Partner[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const loadPartners = useCallback(async () => {
    setLoading(true);
    try {
      const notionPartners = await getPartnersFromNotion();
      if (notionPartners.length > 0) {
        setPartners(notionPartners);
        updateStorage(notionPartners);
      } else {
        const storedPartners = localStorage.getItem(PARTNERS_STORAGE_KEY);
        if (storedPartners) {
          setPartners(JSON.parse(storedPartners));
        } else {
          setPartners([]);
        }
      }
    } catch (error) {
      console.error('Failed to load partners from Notion', error);
      const storedPartners = localStorage.getItem(PARTNERS_STORAGE_KEY);
      setPartners(storedPartners ? JSON.parse(storedPartners) : []);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadPartners();
  }, [loadPartners]);

  const updateStorage = (updatedPartners: Partner[]) => {
    try {
      localStorage.setItem(PARTNERS_STORAGE_KEY, JSON.stringify(updatedPartners));
    } catch (error) {
      console.error('Failed to save partners to localStorage', error);
      toast({
        variant: 'destructive',
        title: 'Storage Error',
        description: 'Could not save partner changes.',
      });
    }
  };

  const addPartner = useCallback((newPartner: Partner) => {
    const slugExists = partners.some(p => p.slug === newPartner.slug);
    if (slugExists) {
        toast({
            variant: 'destructive',
            title: 'Partner Already Exists',
            description: A partner with a similar name already exists. Please choose a different name.,
        });
        return;
    }
    const updatedPartners = [...partners, newPartner];
    setPartners(updatedPartners);
    updateStorage(updatedPartners);
    toast({
        title: 'Partner Added!',
        description: ${newPartner.name} was added. It will be synced from Notion on next refresh.,
    });
  }, [partners, toast]);


  const deletePartner = useCallback((slug: string) => {
    const updatedPartners = partners.filter(p => p.slug !== slug);
    setPartners(updatedPartners);
    updateStorage(updatedPartners);
    toast({
      title: 'Partner Deleted Locally',
      description: 'The AI partner has been removed from your local session.',
    });
  }, [partners, toast]);

  const resetPartners = useCallback(async () => {
    setLoading(true);
    try {
        const notionPartners = await getPartnersFromNotion();
        setPartners(notionPartners);
        updateStorage(notionPartners);
        toast({
            title: 'Partners Synced',
            description: 'Your partner list has been re-synced from Notion.',
        });
    } catch (error) {
        console.error('Failed to reset partners from Notion', error);
        toast({
            variant: 'destructive',
            title: 'Sync Error',
            description: 'Could not connect to Notion to sync partners.',
        });  kayak gini bukan 
    } finally {
        setLoading(false);
    }
  }, [toast]);

  const updatePartner = useCallback((slug: string, updatedPartnerData: Partner) => {
    const updatedPartners = partners.map(p => (p.slug === slug ? updatedPartnerData : p));
    setPartners(updatedPartners);
    updateStorage(updatedPartners);
  }, [partners]);

  const value = { partners, loading, addPartner, deletePartner, resetPartners, updatePartner };

  return <PartnersContext.Provider value={value}>{children}</PartnersContext.Provider>;
}

export function usePartners() {
    const context = useContext(PartnersContext);
    if (context === undefined) {
        throw new Error('usePartners must be used within a PartnersProvider');
    }
    return context;
}                                                                                                                                                      
'use client';

import Link from 'next/link';
import { Bot, LogOut, User as UserIcon, Clock, PanelLeft, Moon, Sun, Home, Play } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useSidebar } from '@/components/ui/sidebar';
import { Skeleton } from './ui/skeleton';
import { Logo } from './logo';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';

function SidebarToggle() {
  const { toggleSidebar } = useSidebar();
  return (
    <Button variant="ghost" size="icon" className="md:hidden" onClick={toggleSidebar}>
      <PanelLeft />
      <span className="sr-only">Toggle Sidebar</span>
    </Button>
  );
}

function ThemeToggle() {
  const [theme, setTheme] = useState('dark');

  useEffect(() => {
    const storedTheme = localStorage.getItem('skillai-theme') || 'dark';
    setTheme(storedTheme);
    document.documentElement.classList.toggle('dark', storedTheme === 'dark');
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    localStorage.setItem('skillai-theme', newTheme);
    document.documentElement.classList.toggle('dark', newTheme === 'dark');
  };

  return (
    <Button variant="ghost" size="icon" onClick={toggleTheme}>
      <Sun className="h-[1.2rem] w-[1.2rem] rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
      <Moon className="absolute h-[1.2rem] w-[1.2rem] rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
      <span className="sr-only">Toggle theme</span>
    </Button>
  );
}

export function SiteHeader() {
  const { user, logout, isTrialActive, daysRemainingInTrial, loading } = useAuth();
  const pathname = usePathname();
  const isAuthPage = pathname === '/login' || pathname === '/register';
  const isPartnerPage = pathname.startsWith('/partner/');
  const isDemoPage = pathname === '/demo';


  const getTrialMessage = () => {
    if (!user) return null;
    if (isTrialActive) {
      return Free trial: ${daysRemainingInTrial} days remaining;
    }
    return 'Free trial has ended.';
  };
  
  const renderNavContent = () => {
    if (loading && !isAuthPage) {
      return (
        <div className="flex items-center gap-4">
          <Skeleton className="hidden h-6 w-48 md:block" />
          <Skeleton className="h-8 w-8 rounded-full" />
        </div>
      );
    }

    if (user) {
      return (
        <>
          <div className="hidden md:flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="h-4 w-4" />
            <span>{getTrialMessage()}</span>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                className="relative h-8 w-8 rounded-full"
              >
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="bg-primary/20 text-accent">
                    <UserIcon className="h-5 w-5" />
                  </AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56" align="end" forceMount>
              <DropdownMenuLabel className="font-normal">
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium leading-none">My Account</p>
                  <p className="text-xs leading-none text-muted-foreground">
                    {user.email}
                  </p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="md:hidden">
                  <Clock className="mr-2 h-4 w-4" />
                  <span>{getTrialMessage()}</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator className="md:hidden" />
              <DropdownMenuItem onClick={logout}>
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </>
      );
    }
    
    return (
       <>
          <Button asChild variant="outline" size="sm">
            <Link href="/demo">
              <Play className="mr-2 h-4 w-4" />
              Lihat Demo
            </Link>
          </Button>
          <Button asChild variant="ghost" size="sm">
            <Link href="/login">Login</Link>
          </Button>
          <Button asChild size="sm">
            <Link href="/register">Register</Link>
          </Button>
        </>
    )
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 max-w-screen-2xl items-center px-4">
        <div className="flex items-center gap-2 mr-auto">
          { !isAuthPage && !isDemoPage && user && (
            <SidebarToggle />
          )}
          <Link href="/" className="flex items-center space-x-2">
            <Logo />
          </Link>
        </div>
        
        <nav className="flex items-center gap-4">
          <ThemeToggle />
           { (isPartnerPage || isDemoPage) && (
            <Button asChild variant="outline" size="sm">
              <Link href="/">
                <Home className="mr-2 h-4 w-4" />
                Home
              </Link>
            </Button>
          )}
          {renderNavContent()}
        </nav>
      </div>
    </header>
  );
}