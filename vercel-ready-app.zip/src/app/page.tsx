// Entry point page
export default function Home() {
  return <div>Hello Vercel</div>;
}